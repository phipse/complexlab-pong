#include <l4/util/util.h>
#include <l4/re/env>
#include <l4/re/namespace>

#include <l4/cxx/exceptions>
#include <l4/cxx/ipc_stream>

#include <l4/re/util/cap_alloc>

#include <stdio.h>
#include <iostream>
#include <pthread-l4.h>

#include <l4/together/keyboard.h>

class Paddle
{
public:
  Paddle( int speed, unsigned long svr );
  void run();

  int connect();
  int lifes();
  void move( int pos );
  int keyConnect();

private:
  unsigned long svr;
  unsigned long pad_cap;
  int speed;
};

class Main
{
public:
  void run();
};

int
Paddle::connect()
{
  L4::Ipc::Iostream s(l4_utcb());
  pad_cap = L4Re::Util::cap_alloc.alloc<void>().cap();
  while (1)
    {  std::cout << "PC: connect to " << std::hex << svr << "\n";
      s << 1UL;
      s << L4::Small_buf(pad_cap);
      l4_msgtag_t err = s.call(svr);
      l4_umword_t fp;
      s >> fp;

      std::cout << "FP: " << fp <<  " err=" << err.raw << "\n";

      if (!l4_msgtag_has_error(err) && fp != 0)
	{
	  std::cout << "Connected to paddle " << (unsigned)fp << '\n';
	  return pad_cap;
	}
      else
	{
	  switch (l4_utcb_tcr()->error)
	    {
	    case L4_IPC_ENOT_EXISTENT:
	      std::cout << "No paddle server found, retry\n";
	      l4_sleep(1000);
	      s.reset();
	      break;
	    default:
	      std::cout << "Connect to paddle failed err=0x"
		       << std::hex << l4_utcb_tcr()->error << '\n';
	      return l4_utcb_tcr()->error;
	    };
	}
    }
  return 0;
}



int Paddle::lifes()
{
  L4::Ipc::Iostream s(l4_utcb());
  s << 3UL;
  if (!l4_msgtag_has_error((s.call(pad_cap))))
    {
      int l;
      s >> l;
      return l;
    }

  return -1;
}



void Paddle::move( int pos )
{
  L4::Ipc::Iostream s(l4_utcb());
  s << 1UL << pos;
  s.call(pad_cap);
  l4_sleep(10);
}



int
Paddle::keyConnect()
{ // connect to keyboard server
  printf( "KeyConnect called\n" ); 
  L4::Cap<void> keyb = L4Re::Env::env()->get_cap<void>( "keyb" );
  L4::Ipc::Iostream io( l4_utcb() );
  
  io << 1;
  io << L4::Cap< L4::Thread >( pthread_getl4cap( pthread_self() ) );
  l4_msgtag_t tag = io.call( keyb.cap() );

  if( tag.has_error () )
    return -1;
  std::cout << "Paddle connected to keyboard\n";

  return 1;
}



Paddle::Paddle(int speed, unsigned long svr)
  : svr(svr), speed(speed)
{}

void Paddle::run()
{
  std::cout << "Pong client running...\n";
  int paddle = connect();
  if (paddle == -1)
    return;
  
  int keyb = keyConnect();
  if( keyb == -1 )
    return;
  
  char up, down;
  
  // valid keys:
  if( speed < 0 )
  {
    up = 'w';
    down = 's';
  }
  else
  {
    up = 'i';
    down = 'k';
  }

  int pos = 180;

  int c = 0;

  L4::Ipc::Istream in( l4_utcb() );
  l4_umword_t sender;
  char key = ' ';
  if( speed < 0 ) speed *= -1;

  while(1)
    {
      in.wait( &sender );
      in >> key;
      in.reset();

      if (c++ >= 500)
	{
	  c = 0;
	  std::cout << '(' << pthread_self() << ") Lifes: " << lifes() << '\n';
	}
      if( key == up )
	pos -= speed;
      else if( key == down )
	pos += speed;
      
      if (pos<0)
	  pos = 0;
      if (pos>1023)
	  pos = 1023;
      move( pos );
    }
}

static l4_cap_idx_t server()
{
  L4::Cap<void> s = L4Re::Env::env()->get_cap<void>("PongServer");
  if (!s)
    throw L4::Element_not_found();

  return s.cap();
}

Paddle p0(-20, server());
Paddle p1(20, server());


void *thread_fn(void* ptr)
{
    Paddle *pd = (Paddle*)ptr;
    pd->run();
    return 0;
}


void Main::run()
{
  std::cout << "Hello from pong example client\n";

  pthread_t p, q;

  pthread_create(&p, NULL, thread_fn, (void*)&p0);
  pthread_create(&q, NULL, thread_fn, (void*)&p1);

  std::cout << "PC: main sleep......\n";
  l4_sleep_forever();

}

int main()
{
  Main().run();
  return 0;
};
